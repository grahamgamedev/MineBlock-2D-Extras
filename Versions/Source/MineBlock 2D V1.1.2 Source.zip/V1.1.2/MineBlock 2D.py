from tkinter import *
import os, webbrowser, World_gen
with open("options.txt", "r") as f:
    exec(f.read())
    
class Window(Frame):
    def __init__(self, master=None):
        # parameters that you want to send through the Frame class. 
        Frame.__init__(self, master)   

        #reference to the master widget, which is the tk window                 
        self.master = master

        #with that, we want to then run init_window, which doesn't yet exist
        self.init_window()

    def init_window(self):     
        self.master.title("MineBlock 2D Launcher")
        img = PhotoImage(file=os.path.join("Texture Packs", "Default", "5.png"))
        self.master.tk.call('wm', 'iconphoto', root._w, img)
        self.pack(fill=BOTH, expand=1)

        # creating a menu instance
        menu = Menu(self.master)
        self.master.config(menu=menu)
        
        # create the file object
        file = Menu(menu)
        file.add_command(label="Exit", command=self.client_exit)
        file.add_command(label="Game folder", command=self.game_folder)
        menu.add_cascade(label="File", menu=file)

        # create the options object
        options = Menu(menu)
        options.add_command(label="Options", command=O.start)
        menu.add_cascade(label="Options", menu=options)

        # create the help object
        hel = Menu(menu)
        hel.add_command(label="Readme", command=self.readme)
        hel.add_command(label="Website", command=self.download)
        hel.add_command(label="Changelog", command=self.changelog)
        menu.add_cascade(label="Help", menu=hel)
        
        # New world button
        button = Button(self, text="New World", width=60, command=W.new_world)
        button.place(x=0, y=0)
        
        self.refresh()
        
    def refresh(self):
        worlds = os.listdir("Worlds")
        if len(worlds) >= 1:
            button = Button(self, text=worlds[0][0:-5], width=50, command=World.world0)
            button.place(x=0, y=50)
            button = Button(self, text="Delete", width=6, command=World.delete0)
            button.place(x=350, y=50)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=50)
            button = Button(self, width=6)
            button.place(x=350, y=50)
            
        if len(worlds) >= 2:
            button = Button(self, text=worlds[1][0:-5], width=50, command=World.world1)
            button.place(x=0, y=80)
            button = Button(self, text="Delete", width=6, command=World.delete1)
            button.place(x=350, y=80)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=80)
            button = Button(self, width=6)
            button.place(x=350, y=80)
            
        if len(worlds) >= 3:
            button = Button(self, text=worlds[2][0:-5], width=50, command=World.world2)
            button.place(x=0, y=110)
            button = Button(self, text="Delete", width=6, command=World.delete2)
            button.place(x=350, y=110)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=110)
            button = Button(self, width=6)
            button.place(x=350, y=110)
            
        if len(worlds) >= 4:
            button = Button(self, text=worlds[3][0:-5], width=50, command=World.world3)
            button.place(x=0, y=140)
            button = Button(self, text="Delete", width=6, command=World.delete3)
            button.place(x=350, y=140)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=140)
            button = Button(self, width=6)
            button.place(x=350, y=140)
            
        if len(worlds) >= 5:
            button = Button(self, text=worlds[4][0:-5], width=50, command=World.world4)
            button.place(x=0, y=170)
            button = Button(self, text="Delete", width=6, command=World.delete4)
            button.place(x=350, y=170)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=170)
            button = Button(self, width=6)
            button.place(x=350, y=170)
            
        if len(worlds) >= 6:
            button = Button(self, text=worlds[5][0:-5], width=50, command=World.world5)
            button.place(x=0, y=200)
            button = Button(self, text="Delete", width=6, command=World.delete5)
            button.place(x=350, y=200)
        else:
            button = Button(self, width=50)
            button.place(x=0, y=200)
            button = Button(self, width=6)
            button.place(x=350, y=200)
    def client_exit(self):
        exit()
    def game_folder(self):
        os.startfile(".")
    def readme(self):
        webbrowser.open("file://" + os.path.realpath("Readme.html"))
    def download(self):
        webbrowser.open("http://mineblock2d.ml/")
    def changelog(self):
        webbrowser.open("http://mineblock2d.ml/changelog.html")

class World():
    # Load world
    def start_world(n):
        global root
        root.destroy()
        worlds = os.listdir("Worlds")
        import main
        main.main(worlds[n])
        
        root = Tk()
        root.geometry("400x300")

        global app
        app = Window(root)
        root.mainloop()
                
    # Delete world
    def delete_world(n=None):
        worlds = os.listdir("Worlds")
        global WORLD
        WORLD = worlds[n][0:-5]
            
        W.root = Tk()
        W.root.title("Delete?")
        W.root.geometry("200x100")
        
        label = Label(W.root, text="Are you shure you want to delete \n" + WORLD)
        label.place(x=0, y=10)
        
        Button(W.root, text="Cancel", command=W.root.destroy).place(x=10, y=70)
        Button(W.root, text="Ok",command=W.rm).place(x=160, y=70)
        W.root.mainloop()
    def rm(self):
        W.root.destroy()
        path = os.path.join("Worlds", WORLD + ".json")
        os.remove(path)
        app.refresh()

    # New world
    def new_world(self):
        self.root = Tk()
        self.root.title("New World")
        self.root.geometry("300x100")
        self.root.bind("<Return>", W.create)
        label = Label(self.root, text="World Name")
        label.place(x=10, y=10)
        self.e = Entry(self.root)
        self.e.place(x=160, y=10)

        button = Button(self.root, text="Create", command=W.create)
        button.pack(side=BOTTOM)
        self.root.mainloop()
    def create(self, a=None):
        world = self.e.get() + ".json"
        worlds = os.listdir("Worlds")
        if world not in worlds and world != ".json":
            World_gen.main(world)
            self.root.destroy()
            app.refresh()
        else:
            label = Label(self.root, text="World allredy exists.")
            label.place(x=50, y=30)
        
                  
    # Load and delete commands for each world
    def world0():
        World.start_world(0)
    def delete0():
        World.delete_world(0)
        
    def world1():
        World.start_world(1)
    def delete1():
        World.delete_world(1)
        
    def world2():
        World.start_world(2)
    def delete2():
        World.delete_world(2)
        
    def world3():
        World.start_world(3)
    def delete3():
        World.delete_world(3)
        
    def world4():
        World.start_world(4)
    def delete4():
        World.delete_world(4)
        
    def world5():
        World.start_world(5)
    def delete5():
        World.delete_world(5)

class Options(Frame):
    def start(self):
        self.root = Tk()
        self.root.geometry("300x250")    
        self.root.title("MineBlock 2D Settings")

        button = Button(self.root, text="Apply", command=self.apply)
        button.pack(side=BOTTOM)
        
        label = Label(self.root, text="Screen width")
        label.place(x=10, y=10)
        self.width = Entry(self.root)
        self.width.place(x=160, y=10)
        self.width.insert(0, SCREEN_WIDTH)
        label = Label(self.root, text="Screen hight")
        label.place(x=10, y=40)
        self.hight = Entry(self.root)
        self.hight.place(x=160, y=40)
        self.hight.insert(0, SCREEN_HEIGHT)

        label = Label(self.root, text="Sky color (R, G, B)")
        label.place(x=10, y=80)
        self.sky = Entry(self.root)
        self.sky.place(x=160, y=80)
        self.sky.insert(0, str(SKY))
        
        label = Label(self.root, text="Skin filename")
        label.place(x=10, y=110)
        self.skin = Entry(self.root)
        self.skin.place(x=160, y=110)
        self.skin.insert(0, SKIN)
        label = Label(self.root, text="Texture pack folder")
        label.place(x=10, y=140)
        self.pack = Entry(self.root)
        self.pack.place(x=160, y=140)
        self.pack.insert(0, PACK)

        root.mainloop()

    def apply(self):
        with open("options.txt", "r") as f:
            opts = f.read().split("\n")
        for i, o in enumerate(opts):
            if len(o) != 0:
                if o.split()[0] == "SCREEN_HEIGHT":
                    opt = opts[i].split(" ")
                    opt[2] = self.hight.get()
                    opts[i] = " ".join(opt)
                if o.split()[0] == "SCREEN_WIDTH":
                    opt = opts[i].split(" ")
                    opt[2] = self.width.get()
                    opts[i] = " ".join(opt)

                if o.split()[0] == "SKY":
                    opt = opts[i].split(" ")
                    opt[2] = self.sky.get()
                    opts[i] = " ".join(opt[0:3])
                    
                if o.split()[0] == "SKIN":
                    opt = opts[i].split(" ")
                    opt[2] = '"' + self.skin.get() + '"'
                    opts[i] = " ".join(opt)
                if o.split()[0] == "PACK":
                    opt = opts[i].split(" ")
                    opt[2] = '"' + self.pack.get() + '"'
                    opts[i] = " ".join(opt)
            with open("options.txt", "w") as f:
                f.write("\n".join(opts))

       
# Part of main window          
root = Tk()
root.geometry("400x300")

W = World()
O = Options()
app = Window(root)

root.mainloop()
