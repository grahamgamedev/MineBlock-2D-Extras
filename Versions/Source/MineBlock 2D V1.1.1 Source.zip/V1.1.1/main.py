import pygame, json, math, random, os.path, time
with open("options.txt", "r") as f:
    exec(f.read())

class Player(pygame.sprite.Sprite):
    def __init__(self, hud):
        super().__init__()
 
        self.image = pygame.image.load(SKIN)
        self.rect = self.image.get_rect()
 
        # Set speed vector of player
        self.change_x = 0
        self.change_y = 0
 
        # List of sprites we can bump against
        self.level = None
        self.hud = hud
        self.facing = "RIGHT"
        
    def update(self):
        # Gravity
        self.calc_grav()

        # Void damage
        if self.rect.y - VS > 5000:
            self.hud.health(-10)
 
        # Move left/right
        self.rect.x += self.change_x
 
        # See if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        for block in block_hit_list:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right
 
        # Move up/down
        self.rect.y += self.change_y
 
        # Check and see if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        for block in block_hit_list:
            # Fall damage
            if self.change_y > 1:
                if self.change_y > 10:
                    self.hud.health(- round(self.change_y / 4 -3))
                    
            # Reset our position based on the top/bottom of the object.
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom
    
            # Stop our vertical movement
            self.change_y = 0
 
    def calc_grav(self):
        if self.change_y == 0:
            self.change_y = 1
        else:
            self.change_y += 0.35
        # See if we are on the ground.
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.change_y >= 0:
            self.change_y = 0
            self.rect.y = SCREEN_HEIGHT - self.rect.height
            
    def jump(self):
        # move down a bit and see if there is a platform below us.
        self.rect.y += 2
        platform_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        self.rect.y -= 2
 
        # If it is ok to jump, set our speed upwards
        if len(platform_hit_list) > 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.change_y = -9
 
    # Player movement
    def go_left(self):
        self.change_x = -6
        self.facing = "LEFT"
    def go_right(self):
        self.change_x = 6
        self.facing = "RIGHT"
    def stop(self):
        self.change_x = 0

class Block(pygame.sprite.Sprite):
    def __init__(self, bid, scale=100):
        super().__init__()
        # Load textures and create blocks
        self.image = pygame.image.load(os.path.join("Texture Packs", PACK, str(bid) + ".png")).convert_alpha()
        if scale != 100:
            if bid == 11:
                self.image = pygame.transform.scale(self.image, (scale, 10))
            elif bid == 105:
                self.image = pygame.transform.scale(self.image, (int(scale / 2), scale))
            else:   
                self.image = pygame.transform.scale(self.image, (scale, scale))
        self.rect = self.image.get_rect()

class world:
    def __init__(self, player, hud, world_name):
        self.forground_list = pygame.sprite.Group()
        self.background_list = pygame.sprite.Group()
        self.world_shift = 0
        self.vworld_shift = 0
        self.player = player
        self.hud = hud

        global level
        # World Shift
        global WS
        global VS
        
        with open(os.path.join("Worlds", world_name), "r") as f:
            d = json.loads(f.read())
        level = d["Level"]
        WS = d["WS"]
        VS = d["VS"]
        player.rect.x = d["X"]
        player.rect.y = d["Y"]
        self.hud.hot = d["Hot"]
        self.hud.curent_health = d["Health"]

        # Block properties [bid, brakeable, bid to get]
        self.block_types = [[1,True,1], [2,True,2], [3,True,3], [5,False,0], [6,True,6], [7,True,7], [8,True,8], [10,True,10], [11,True,107], [12,True,105], [13,True,105],
                            [100,True,100], [101,True,0], [102,True,0], [103,True,103], [104,True,104], [105,True,105], [106,True,105], [107,True,107], [108,True,108]]   

        x = math.floor(-(WS - player.rect.x) / 100)
        self.chright = math.floor(x / 16)
        self.chleft = math.floor(x / 16)
        
        # Correct world shift      
        self.shift_world(WS)
        self.vshift_world(VS)
        self.hud.blocks()
        self.hud.health(0)

        # Load chunks
        self.load(self.chright)
        self.chright += 1
        self.chleft -= 1
        self.load(self.chright)
        self.load(self.chleft)
        self.chright += 1
        self.chleft -= 1

    def load(self, chunk):
        if -128 <= chunk * 16 < 128:
            for c in level:
                if c[0] == chunk:
                    for b in c[1:]:
                        block = Block(b[2])
                        block.rect.x = b[0] * 100 + WS
                        block.rect.y = b[1] * 100 + VS
                        block.player = self.player
                        if b[2] >= 100:
                            self.background_list.add(block)
                        else:
                            self.forground_list.add(block)
 
    def shift_world(self, shift_x):
        self.world_shift += shift_x
        global WS
        WS = self.world_shift
 
        # Go through all the sprite lists and shift
        for platform in self.forground_list:
            platform.rect.x += shift_x
        for platform in self.background_list:
            platform.rect.x += shift_x

        # Load extra chunks
        x = math.floor(-(WS - player.rect.x) / 100)
        if (x + 3) / 16 == self.chright:
            self.load(self.chright)
            self.chright += 1
        if (x - 19) / 16 == self.chleft:
            self.load(self.chleft)
            self.chleft -= 1

    def vshift_world(self, shift_y):
        self.vworld_shift += shift_y
        global VS
        VS = self.vworld_shift
 
        # Go through all the sprite lists and shift
        for platform in self.forground_list:
            platform.rect.y += shift_y
        for platform in self.background_list:
            platform.rect.y += shift_y

    def draw(self, screen):
        # Draw the background
        screen.fill(SKY)
        # Draw all the sprite lists that we have
        self.background_list.draw(screen)
        self.forground_list.draw(screen)
        
    def mine(self, x = None, y = None):
        get = False
        if x == None:
            pos = pygame.mouse.get_pos()
            x = math.floor((pos[0] - WS) / 100)
            y = math.floor((pos[1] - VS) / 100)
            get = True
        for c in level:
            if c[0] in range(self.chleft, self.chright):
                for i, b in enumerate(c[1:]):
                    if [x, y] == b[0:2]:
                        for t in self.block_types:
                            if t[0] == b[2]:
                                prop = t
                        if prop[1]:
                            if prop[2] != 0 and get:
                                self.hud.add_block(prop[2])
                            level.remove(c)
                            c.remove(b)
                            level.append(c)
                            for platform in self.forground_list:
                                if x * 100 + WS == platform.rect.x:
                                    if y * 100 + VS == platform.rect.y:
                                        self.forground_list.remove(platform)
                            for platform in self.background_list:
                                if x * 100 + WS == platform.rect.x:
                                    if y * 100 + VS == platform.rect.y:
                                        self.background_list.remove(platform) 
    def place(self):
        pos = pygame.mouse.get_pos()
        x = math.floor((pos[0] - WS) / 100)
        y = math.floor((pos[1] - VS) / 100)
        bid = self.hud.held[2]
        get = True
        exist = False
        for c in level:
            for i, b in enumerate(c[3:]):
                if [x, y] == b[0:2]:
                    if b[2] == 107:
                        self.mine(b[0], b[1])
                        bid = 11
                        get = False
                    elif b[2] == 11:
                        self.mine(b[0], b[1])
                        bid = 107
                        get = False
                    elif b[2] == 105:
                        self.mine(b[0], b[1])
                        bid = 12
                        get = False
                    elif b[2] == 12:
                        self.mine(b[0], b[1])
                        bid = 105
                        get = False
                    elif b[2] == 106:
                        self.mine(b[0], b[1])
                        bid = 13
                        get = False
                    elif b[2] == 13:
                        self.mine(b[0], b[1])
                        bid = 106
                        get = False
                    else:
                        exist = True
        
        if not exist and bid != 0: 
            if get:
                self.hud.rm_block(1)
                if player.facing == "RIGHT" and bid == 105:
                    bid = 106
            for c in level:
                if c[0] == math.floor(x / 16):
                    level.remove(c)
                    c.append([x, y, bid])
                    level.append(c)
            
            block = Block(bid)
            block.rect.x = x * 100 + WS
            block.rect.y = y * 100 + VS
            block.player = self.player
            if bid >= 100:
                self.background_list.add(block)
            else:
                self.forground_list.add(block)
            
class HUD():
    def __init__(self):
        self.hot = []
        self.h = None 
        pygame.font.init()
        self.myfont = pygame.font.Font(FONT, FONT_SIZE)
        self.before = time.time()
        self.selection = 0

        # [bid to craft, bids,required,0,0,0, quantity to get]
        self.recipies = [[10, 100,0,0,0,0, 1], [107, 10,0,0,0,0, 4], [105, 10,0,0,0,0, 2], [108, 10,10,0,0,0, 1]]
        
    def blocks(self):
        self.hot_list = pygame.sprite.Group()
        if self.h == None:
            self.change(1)
        gap = "       "
        text = " "
        # Go through hot and add blocks
        for b in self.hot:
            if b[2] != 0:
                block = Block(b[2], scale=50)
                block.rect.x = b[0] * 100
                block.rect.y = b[1] * 100
                self.hot_list.add(block)
            if b == self.held:
                block = Block("Hotbar2", scale=50)
            else:
                block = Block("Hotbar1", scale=50)
            block.rect.x = b[0] * 100
            block.rect.y = b[1] * 100
            self.hot_list.add(block)
            
            if len(str(b[3])) == 2:
                text += str(b[3]) + gap
            elif len(str(b[3])) == 1:
                text += str(b[3]) + gap + " "   
        self.textsurface = self.myfont.render(text, False, (0, 0, 0))
        
    def change(self, n):
        self.held = self.hot[n-1]
        self.h = n -1
        self.blocks()

    def add_block(self, bid):
        cont = True
        for i, b in enumerate(self.hot):
            if b[2] == bid and cont:
                if not self.hot[i][3] >= 64:
                    self.hot[i][3] += 1
                    cont = False
        if cont:
            for i, b in enumerate(self.hot):
                if b[2] == 0 and cont:
                    self.hot[i][2] = bid
                    self.hot[i][3] += 1
                    cont = False
        self.blocks()
    def rm_block(self, number):
        self.hot[self.h][3] -= number
        if self.hot[self.h][3] <= 0:
            self.hot[self.h][2] = 0
        self.blocks()
        
    def health(self, health):
        self.curent_health += health
        self.health_list = pygame.sprite.Group()
        x = SCREEN_WIDTH
        for i in range(self.curent_health):
            block = Block("health1")
            x -= 30
            block.rect.x = x
            block.rect.y = 10
            self.health_list.add(block)

    def crafting(self):
        self.crafting_list = pygame.sprite.Group()
        x = 50
        block = Block("Crafting1")
        block.rect.x = 100
        block.rect.y = 150
        self.crafting_list.add(block)
        gap = "         "
        text = " "
        
        # Go through recipies and add ingrediants
        for i, b in enumerate(self.recipies):
            block = Block(b[0], scale=50)
            x += 60
            block.rect.x = x
            block.rect.y = 450
            self.crafting_list.add(block)
            if i == self.selection:
                block = Block("Crafting3")
                block.rect.x = x
                block.rect.y = 450
                self.crafting_list.add(block)

            if b[1] != 0:
                block = Block(b[1], scale=50)
                block.rect.x = x
                block.rect.y = 380
                self.crafting_list.add(block)
                got = False
                for h in self.hot:
                    if b[1] == h[2]:
                        got = True
                if not got:
                    block = Block("Crafting2")
                    block.rect.x = x
                    block.rect.y = 380
                    self.crafting_list.add(block)
            if b[2] != 0:
                block = Block(b[2], scale=50)
                block.rect.x = x
                block.rect.y = 325
                self.crafting_list.add(block)
                got = False
                for h in self.hot:
                    if b[2] == h[2]:
                        got = True
                if not got:
                    block = Block("Crafting2")
                    block.rect.x = x
                    block.rect.y = 325
                    self.crafting_list.add(block)
            if b[3] != 0:
                block = Block(b[3], scale=50)
                block.rect.x = x
                block.rect.y = 270
                self.crafting_list.add(block)
                got = False
                for h in self.hot:
                    if b[3] == h[2]:
                        got = True 
                if not got:
                    block = Block("Crafting2")
                    block.rect.x = x
                    block.rect.y = 270
                    self.crafting_list.add(block)
            if b[4] != 0:
                block = Block(b[4], scale=50)
                block.rect.x = x
                block.rect.y = 215
                self.crafting_list.add(block)
                got = False
                for h in self.hot:
                    if b[4] == h[2]:
                        got = True
                if not got:
                    block = Block("Crafting2")
                    block.rect.x = x
                    block.rect.y = 215
                    self.crafting_list.add(block)
            if b[5] != 0:
                block = Block(b[5], scale=50)
                block.rect.x = x
                block.rect.y = 160
                self.crafting_list.add(block)
                got = False
                for h in self.hot:
                    if b[5] == h[2]:
                        got = True
                if not got:
                    block = Block("Crafting2")
                    block.rect.x = x
                    block.rect.y = 160
                    self.crafting_list.add(block)
                
            if len(str(b[-1])) == 2:
                text += str(b[-1]) + gap
            elif len(str(b[-1])) == 1:
                text += str(b[-1]) + gap + " "
        self.craftingtext = self.myfont.render(text, False, (0, 0, 0))
                    
    def craft(self):
        for r in self.recipies[self.selection][1:-1]:
            if r != 0:
                cont = True
                for i, b in enumerate(self.hot):
                    if b[2] == r and cont:
                        self.hot[i][3] -= 1
                        if self.hot[i][3] <= 0:
                            self.hot[i][2] = 0
                        self.blocks()
                        cont = False
        if not cont:
            for i in range(self.recipies[self.selection][-1]):
                self.add_block(self.recipies[self.selection][0])
        self.crafting()
                
    def select_recipie(self, left):
        if left and self.selection > 0:
            self.selection -= 1
            self.crafting()
        elif self.selection < len(self.recipies) -1:
            self.selection += 1
            self.crafting()
               
    def draw(self, screen):
        self.hot_list.draw(screen)
        screen.blit(self.textsurface,(0,55))
        self.health_list.draw(screen)
        if CRAFTING:
            self.crafting_list.draw(screen)
            screen.blit(self.craftingtext,(110,480))
        if DEBUG:
            screen.blit(self.debug,(0,100))

    def update(self):
        if time.time() - self.before > 30 and self.curent_health < 10:
            self.before = time.time()
            self.health(1) 
        if DEBUG:
            y = math.floor(-(VS - player.rect.y) / 100)
            x = math.floor(-(WS - player.rect.x) / 100)
            text = " Player: X " + str(x) + "  Y " + str(y)
            pos = pygame.mouse.get_pos()
            x = math.floor((pos[0] - WS) / 100)
            y = math.floor((pos[1] - VS) / 100)
            text += "  Mouse: X " + str(x) + "  Y " + str(y)
            self.debug = self.myfont.render(text, False, (0, 0, 0))
    

def main(world_name):
    pygame.init()

    # Set the height and width of the screen
    size = (SCREEN_WIDTH, SCREEN_HEIGHT)
    screen = pygame.display.set_mode(size)
    ro = SCREEN_WIDTH - 150
    bo = SCREEN_HEIGHT - 150

    # Icon
    pygame.display.set_caption("MineBlock 2D")
    icon = pygame.image.load(os.path.join("Texture Packs", PACK, "5.png"))
    pygame.display.set_icon(icon)

    # Loading screen
    load = str(random.randint(1, 3))
    loading = pygame.image.load(os.path.join("Texture Packs", PACK, "Loading" + load + ".png")).convert()
    loading = pygame.transform.scale(loading, (SCREEN_WIDTH, SCREEN_HEIGHT))
    screen.blit(loading, (0,0))
    pygame.display.flip()

    # Load HUD
    hud = HUD()
    global CRAFTING
    
    # Create the player
    global player
    player = Player(hud)
    active_sprite_list = pygame.sprite.Group()
    active_sprite_list.add(player)

    # Load world
    current_level = world(player, hud, world_name)
    player.level = current_level

    # Used to manage how fast the screen updates
    clock = pygame.time.Clock()

    # -------- Main Program Loop -----------
    dead = False
    done = False
    while not done:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    if CRAFTING:
                        hud.select_recipie(True)
                    else:
                        player.go_left()
                if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    if CRAFTING:
                        hud.select_recipie(False)
                    else:
                        player.go_right()
                if event.key == pygame.K_SPACE:
                    if not CRAFTING:
                        player.jump()
                if event.key == pygame.K_e:
                    if CRAFTING:
                        CRAFTING = False
                    else:
                        hud.crafting()
                        CRAFTING = True
                if event.key == pygame.K_c:
                    if CRAFTING:
                        hud.craft()
                        
                if event.key == pygame.K_ESCAPE:
                    if CRAFTING:
                        CRAFTING = False
                    else:
                        done = True
                if event.key == pygame.K_F3:
                    global DEBUG
                    if DEBUG:
                        DEBUG = False
                    else:
                        DEBUG = True
                    
                if event.key == pygame.K_1:
                    hud.change(1)
                if event.key == pygame.K_2:
                    hud.change(2)
                if event.key == pygame.K_3:
                    hud.change(3)
                if event.key == pygame.K_4:
                    hud.change(4)
                if event.key == pygame.K_5:
                    hud.change(5)
                if event.key == pygame.K_6:
                    hud.change(6)
                if event.key == pygame.K_7:
                    hud.change(7)
                if event.key == pygame.K_8:
                    hud.change(8)
                if event.key == pygame.K_9:
                    hud.change(9)
                
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_a and player.change_x < 0:
                    player.stop()
                if event.key == pygame.K_RIGHT or event.key == pygame.K_d and player.change_x > 0:
                    player.stop()
                    
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and not CRAFTING:
                    current_level.mine()
                if event.button == 3 and not CRAFTING:
                    current_level.place()

        # Update the player.
        active_sprite_list.update()
        # Update HUD
        hud.update()

        # Check that the player is alive
        if hud.curent_health <= 0:
            done = True
            dead = True

        # If the player gets near the right side, shift the world left (-x)
        if player.rect.right >= ro:
            diff = player.rect.right - ro
            player.rect.right = ro
            current_level.shift_world(-diff)

        # If the player gets near the left side, shift the world right (+x)
        if player.rect.left <= 150:
            diff = 150 - player.rect.left
            player.rect.left = 150
            current_level.shift_world(diff)

        # If the player gets near the bottom side, shift the world up (-y)
        if player.rect.bottom >= bo:
            diff = player.rect.bottom - bo
            player.rect.bottom = bo
            current_level.vshift_world(-diff)

        # If the player gets near the top side, shift the world down (+y)
        if player.rect.top <= 150:
            diff = 150 - player.rect.top
            player.rect.top = 150
            current_level.vshift_world(diff)

        # ALL CODE TO DRAW SHOULD GO BELOW THIS COMMENT
        current_level.draw(screen)
        active_sprite_list.draw(screen)
        hud.draw(screen)

        # Limit to 60 frames per second
        clock.tick(60)

        # Go ahead and update the screen with what we've drawn.
        pygame.display.flip()

    # Death screen    
    restart = False
    if dead:
        death = pygame.image.load(os.path.join("Texture Packs", PACK, "Death.png")).convert()
        death = pygame.transform.scale(death, (SCREEN_WIDTH, SCREEN_HEIGHT))
        screen.blit(death, (0,0))
        pygame.display.flip()
        while dead:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    dead = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        dead = False
                    if event.key == pygame.K_RETURN:
                        restart = True
                        dead = False        
        hud.curent_health = 10
        hud.hot = [[0, 0, 0, 0], [0.5, 0, 0, 0], [1, 0, 0, 0], [1.5, 0, 0, 0], [2, 0, 0, 0], [2.5, 0, 0, 0], [3, 0, 0, 0], [3.5, 0, 0, 0], [4, 0, 0, 0]]
        player.rect.x = 0
        player.rect.y = 200
        global WS
        WS = 0
        global VS
        VS = -2000
        
    # Save
    with open(os.path.join("Worlds", world_name), "w") as f:
        f.write('{"Level":' + str(level) + ",\n")
        f.write('"WS":' + str(WS) + ', "VS":' + str(VS) + ', "X":' + str(player.rect.x) + ', "Y":' + str(player.rect.y) + ", \n")
        f.write('"Hot":' + str(hud.hot) + ', \n"Health":' + str(hud.curent_health) + '}')

    if restart:
        main(world_name)
    else:
        pygame.quit()

# Uncomment to bypass launcher    
#main("test.json")


        
        

