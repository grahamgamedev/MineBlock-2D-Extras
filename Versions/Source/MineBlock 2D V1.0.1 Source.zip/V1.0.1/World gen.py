import random, os.path
with open("options.txt", "r") as f:
    exec(f.read())
    
level = []
ch = None
rand = 0

# Hotbar coords
hot = [[0, 0, 0, 0], [0.5, 0, 0, 0], [1, 0, 0, 0], [1.5, 0, 0, 0], [2, 0, 0, 0], [2.5, 0, 0, 0], [3, 0, 0, 0], [3.5, 0, 0, 0], [4, 0, 0, 0]]

def tree(x, y, trand):
        if trand == 1:
                ch.append([x,y,100])
                ch.append([x,y-1,100])
                ch.append([x+1,y-1,101])
                ch.append([x-1,y-1,101])
                ch.append([x+2,y-1,101])
                ch.append([x-2,y-1,101])
                ch.append([x,y-2,101])
                ch.append([x+1,y-2,101])
                ch.append([x-1,y-2,101])
                ch.append([x,y-3,101])
        elif trand == 2:
                ch.append([x,y,100])
                ch.append([x,y-1,100])
                ch.append([x,y-2,100])
                ch.append([x+1,y-2,101])
                ch.append([x-1,y-2,101])
                ch.append([x+2,y-2,101])
                ch.append([x-2,y-2,101])
                ch.append([x,y-3,101])
                ch.append([x+1,y-3,101])
                ch.append([x-1,y-3,101])
                ch.append([x,y-4,101])

print("Generating")
for x in range(-128, 128 + 1):
        # Start new chunk
        if ch == None:
              ch = [round(x / 16)]  
        if x % 16 == 0:
                print(round(x / 16))
                level.append(ch)
                ch = [round(x / 16)]
                
        # Underground
        for y in range(29, 49):
                ch.append([x,y,3])
        ch.append([x,50,5])
        ch.append([x,49,5])
        
        # Ground level
        if rand == 0:
                rand = random.randint(1, 10)
        # High
        if rand > 4:
                ch.append([x,28,3])
                if random.randint(1, 2) == 1:
                        ch.append([x,27,3])
                else:
                        ch.append([x,27,2])
                ch.append([x,26,2])
                ch.append([x,25,2])
                ch.append([x,24,1])

                # Vegitation
                trand = random.randint(1, 50)
                if trand < 3:
                      tree(x, 23, trand)  
                elif random.randint(1, 5) == 1:
                        ch.append([x,23,102])
                elif random.randint(1, 7) == 1:
                        ch.append([x,23,103])
                elif random.randint(1, 7) == 1:
                        ch.append([x,23,104])
        # Low           
        else:
                if random.randint(1, 2) == 1:
                        ch.append([x,28,3])
                else:
                        ch.append([x,28,2])
                ch.append([x,27,2])
                ch.append([x,26,2])
                ch.append([x,25,1])

                # Vegitation
                trand = random.randint(1, 50)
                if trand < 3:
                      tree(x, 24, trand)  
                elif random.randint(1, 5) == 1:
                        ch.append([x,24,102])
                elif random.randint(1, 7) == 1:
                        ch.append([x,24,103])
                elif random.randint(1, 7) == 1:
                        ch.append([x,24,104])
        rand -= 1

# Save
with open(os.path.join("Worlds", WORLD), "w") as f:
        f.write('{"Level":' + str(level[1:]) + ', \n"WS":0, "VS":-2000, "X":0, "Y":200, \n"Hot":' + str(hot) + '}')
print("Finished")
