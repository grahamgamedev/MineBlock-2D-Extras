import pygame, json, math, os.path
with open("options.txt", "r") as f:
    exec(f.read())

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
 
        self.image = pygame.image.load(SKIN)
        self.rect = self.image.get_rect()
 
        # Set speed vector of player
        self.change_x = 0
        self.change_y = 0
 
        # List of sprites we can bump against
        self.level = None
 
    def update(self):
        # Gravity
        self.calc_grav()
 
        # Move left/right
        self.rect.x += self.change_x
 
        # See if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        for block in block_hit_list:
            # If we are moving right,
            # set our right side to the left side of the item we hit
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                # Otherwise if we are moving left, do the opposite.
                self.rect.left = block.rect.right
 
        # Move up/down
        self.rect.y += self.change_y
 
        # Check and see if we hit anything
        block_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        for block in block_hit_list:
            # Reset our position based on the top/bottom of the object.
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom
 
            # Stop our vertical movement
            self.change_y = 0
 
    def calc_grav(self):
        if self.change_y == 0:
            self.change_y = 1
        else:
            self.change_y += 0.35
            
        # See if we are on the ground.
        if self.rect.y >= SCREEN_HEIGHT - self.rect.height and self.change_y >= 0:
            self.change_y = 0
            self.rect.y = SCREEN_HEIGHT - self.rect.height
 
    def jump(self):
        # move down a bit and see if there is a platform below us.
        self.rect.y += 2
        platform_hit_list = pygame.sprite.spritecollide(self, self.level.forground_list, False)
        self.rect.y -= 2
 
        # If it is ok to jump, set our speed upwards
        if len(platform_hit_list) > 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.change_y = -9
 
    # Player movement
    def go_left(self):
        self.change_x = -6
    def go_right(self):
        self.change_x = 6
    def stop(self):
        self.change_x = 0

class Block(pygame.sprite.Sprite):
    def __init__(self, bid, scale=100):
        super().__init__()
        # Load textures and create blocks
        self.image = pygame.image.load(os.path.join("Texture Packs", PACK, str(bid) + ".png")).convert_alpha()
        if scale != 100:
            self.image = pygame.transform.scale(self.image, (scale, scale))
        self.rect = self.image.get_rect()

class world:
    def __init__(self, player, hud):
        self.forground_list = pygame.sprite.Group()
        self.background_list = pygame.sprite.Group()
        self.world_shift = 0
        self.vworld_shift = 0
        self.player = player
        self.hud = hud

        global level
        # World Shift
        global WS
        global VS
        
        with open(os.path.join("Worlds", WORLD), "r") as f:
            d = json.loads(f.read())
        level = d["Level"]
        WS = d["WS"]
        VS = d["VS"]
        player.rect.x = d["X"]
        player.rect.y = d["Y"]
        hud.hot = d["Hot"]

        # Block properties [bid, brakeable, bid to get]
        self.block_types = [[1,True,1], [2,True,2], [3,True,3], [4,True,4], [5,False,0], [100,True,100], [101,True,0], [102,True,0], [103,True,103], [104,True,104]]   

        x = math.floor(-(WS - player.rect.x) / 100)
        self.chright = math.floor(x / 16)
        self.chleft = math.floor(x / 16)
        
        # Correct world shift      
        self.shift_world(WS)
        self.vshift_world(VS)
        self.hud.blocks()

        # Load chunks
        self.load(self.chright)
        self.chright += 1
        self.chleft -= 1
        self.load(self.chright)
        self.load(self.chleft)
        self.chright += 1
        self.chleft -= 1

    def load(self, chunk):
        if -128 <= chunk * 16 < 128:
            for c in level:
                if c[0] == chunk:
                    for b in c[1:]:
                        block = Block(b[2])
                        block.rect.x = b[0] * 100 + WS
                        block.rect.y = b[1] * 100 + VS
                        block.player = self.player
                        if b[2] >= 100:
                            self.background_list.add(block)
                        else:
                            self.forground_list.add(block)
 
    def shift_world(self, shift_x):
        self.world_shift += shift_x
        global WS
        WS = self.world_shift
 
        # Go through all the sprite lists and shift
        for platform in self.forground_list:
            platform.rect.x += shift_x
        for platform in self.background_list:
            platform.rect.x += shift_x

        # Load extra chunks
        x = math.floor(-(WS - player.rect.x) / 100)
        if (x + 3) / 16 == self.chright:
            self.load(self.chright)
            self.chright += 1
        if (x - 19) / 16 == self.chleft:
            self.load(self.chleft)
            self.chleft -= 1

    def vshift_world(self, shift_y):
        self.vworld_shift += shift_y
        global VS
        VS = self.vworld_shift
 
        # Go through all the sprite lists and shift
        for platform in self.forground_list:
            platform.rect.y += shift_y
        for platform in self.background_list:
            platform.rect.y += shift_y

    def draw(self, screen):
        # Draw the background
        screen.fill(SKY)
        # Draw all the sprite lists that we have
        self.background_list.draw(screen)
        self.forground_list.draw(screen)
        
    def mine(self):
        pos = pygame.mouse.get_pos()
        x = math.floor((pos[0] - WS) / 100)
        y = math.floor((pos[1] - VS) / 100)
        for c in level:
            if c[0] in range(self.chleft, self.chright):
                for i, b in enumerate(c[1:]):
                    if [x, y] == b[0:2]:
                        for t in self.block_types:
                            if t[0] == b[2]:
                                prop = t
                        if prop[1]:
                            if prop[2] != 0:
                                self.hud.add_block(prop[2])
                            level.remove(c)
                            c.remove(b)
                            level.append(c)
                            for platform in self.forground_list:
                                if x * 100 + WS == platform.rect.x:
                                    if y * 100 + VS == platform.rect.y:
                                        self.forground_list.remove(platform)
                            for platform in self.background_list:
                                if x * 100 + WS == platform.rect.x:
                                    if y * 100 + VS == platform.rect.y:
                                        self.background_list.remove(platform) 
    def place(self, bid):
        pos = pygame.mouse.get_pos()
        x = math.floor((pos[0] - WS) / 100)
        y = math.floor((pos[1] - VS) / 100)
        bid = self.hud.held[2]
        
        exist = False
        for c in level:
            for i, b in enumerate(c[3:]):
                if [x, y] == b[0:2]:
                    exist = True
        if not exist and bid != 0:
            self.hud.rm_block(1)
            for c in level:
                if c[0] == math.floor(x / 16):
                    level.remove(c)
                    c.append([x, y, bid])
                    level.append(c)
                    
            block = Block(bid)
            block.rect.x = x * 100 + WS
            block.rect.y = y * 100 + VS
            block.player = self.player
            if bid >= 100:
                self.background_list.add(block)
            else:
                self.forground_list.add(block)
            
class HUD():
    def __init__(self):
        self.hot = []
        self.h = None 
        pygame.font.init()
        self.myfont = pygame.font.SysFont(FONT, FONT_SIZE)
                        
    def blocks(self):
        self.hot_list = pygame.sprite.Group()
        if self.h == None:
            self.change(1)
        gap = "       "
        text = " "
        # Go through hot and add blocks
        for b in self.hot:
            if b[2] != 0:
                block = Block(b[2], scale=50)
                block.rect.x = b[0] * 100
                block.rect.y = b[1] * 100
                self.hot_list.add(block)
            if b == self.held:
                block = Block("Hotbar2", scale=50)
            else:
                block = Block("Hotbar1", scale=50)
            block.rect.x = b[0] * 100
            block.rect.y = b[1] * 100
            self.hot_list.add(block)
            
            if len(str(b[3])) == 2:
                text += str(b[3]) + gap
            elif len(str(b[3])) == 1:
                text += str(b[3]) + gap + " "   
        self.textsurface = self.myfont.render(text, False, (0, 0, 0))

    def update(self):
        if DEBUG:
            y = math.floor(-(VS - player.rect.y) / 100)
            x = math.floor(-(WS - player.rect.x) / 100)
            text = " Player: X " + str(x) + "  Y " + str(y)
            pos = pygame.mouse.get_pos()
            x = math.floor((pos[0] - WS) / 100)
            y = math.floor((pos[1] - VS) / 100)
            text += "  Mouse: X " + str(x) + "  Y " + str(y)
            self.debug = self.myfont.render(text, False, (0, 0, 0))
        
    def draw(self, screen):
        self.hot_list.draw(screen)
        screen.blit(self.textsurface,(0,55))
        if DEBUG:
            screen.blit(self.debug,(0,70))

    def change(self, n):
        self.held = self.hot[n-1]
        self.h = n -1
        self.blocks()

    def add_block(self, bid):
        cont = True
        for i, b in enumerate(self.hot):
            if b[2] == bid and cont:
                if not self.hot[i][3] >= 64:
                    self.hot[i][3] += 1
                    cont = False
        if cont:
            for i, b in enumerate(self.hot):
                if b[2] == 0 and cont:
                    self.hot[i][2] = bid
                    self.hot[i][3] += 1
                    cont = False
        self.blocks()

    def rm_block(self, number):
        self.hot[self.h][3] -= number
        if self.hot[self.h][3] <= 0:
            self.hot[self.h][2] = 0
        self.blocks()
    
            
pygame.init()

# Set the height and width of the screen
size = [SCREEN_WIDTH, SCREEN_HEIGHT]
screen = pygame.display.set_mode(size)
ro = SCREEN_WIDTH - 150
bo = SCREEN_HEIGHT - 150

# Icon
pygame.display.set_caption("MineBlock 2D")
icon = pygame.image.load(os.path.join("Texture Packs", PACK, "4.png"))
pygame.display.set_icon(icon)

# Loading screen
loading = pygame.image.load(os.path.join("Texture Packs", PACK, "Loading1.png")).convert()
screen.blit(loading, (0,0))
pygame.display.flip()

# Create the player
player = Player()
active_sprite_list = pygame.sprite.Group()
active_sprite_list.add(player)

# Load HUD
hud = HUD()

# Load world
current_level = world(player, hud)
player.level = current_level

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# -------- Main Program Loop -----------
done = False
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.go_left()
            if event.key == pygame.K_RIGHT:
                player.go_right()
            if event.key == pygame.K_SPACE:
                player.jump()
            if event.key == pygame.K_ESCAPE:
                done = True
                
            if event.key == pygame.K_1:
                hud.change(1)
            if event.key == pygame.K_2:
                hud.change(2)
            if event.key == pygame.K_3:
                hud.change(3)
            if event.key == pygame.K_4:
                hud.change(4)
            if event.key == pygame.K_5:
                hud.change(5)
            if event.key == pygame.K_6:
                hud.change(6)
            if event.key == pygame.K_7:
                hud.change(7)
            if event.key == pygame.K_8:
                hud.change(8)
            if event.key == pygame.K_9:
                hud.change(9)
            
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT and player.change_x < 0:
                player.stop()
            if event.key == pygame.K_RIGHT and player.change_x > 0:
                player.stop()
                
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                current_level.mine()
            if event.button == 3:
                current_level.place(4)

    # Update the player.
    active_sprite_list.update()
    # Update HUD
    hud.update()

    # If the player gets near the right side, shift the world left (-x)
    if player.rect.right >= ro:
        diff = player.rect.right - ro
        player.rect.right = ro
        current_level.shift_world(-diff)

    # If the player gets near the left side, shift the world right (+x)
    if player.rect.left <= 150:
        diff = 150 - player.rect.left
        player.rect.left = 150
        current_level.shift_world(diff)

    # If the player gets near the bottom side, shift the world up (-y)
    if player.rect.bottom >= bo:
        diff = player.rect.bottom - bo
        player.rect.bottom = bo
        current_level.vshift_world(-diff)

    # If the player gets near the top side, shift the world down (+y)
    if player.rect.top <= 150:
        diff = 150 - player.rect.top
        player.rect.top = 150
        current_level.vshift_world(diff)

    # ALL CODE TO DRAW SHOULD GO BELOW THIS COMMENT
    current_level.draw(screen)
    active_sprite_list.draw(screen)
    hud.draw(screen)

    # Limit to 60 frames per second
    clock.tick(60)

    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()


# Save
with open(os.path.join("Worlds", WORLD), "w") as f:
    f.write('{"Level":' + str(level) + ', \n"WS":' + str(WS) + ', "VS":' + str(VS) + ', "X":' + str(player.rect.x) + ', "Y":' + str(player.rect.y) + ', \n"Hot":' + str(hud.hot) + '}')

pygame.quit()




        
        

